<#
Open-site.ps1
Usage: double-click or run in PowerShell. It will attempt to:
  1) open http://localhost:8000/groceryStore.html if a local static server is running
  2) if not, try to start a Python static server (python -m http.server 8000) in a new window and then open the page
  3) if Python isn't available, open the file directly with the default browser

It will prefer Google Chrome if installed, otherwise uses the system default browser.
#>

param(
  [string]$Page = 'groceryStore.html',
  [int]$Port = 8000
)

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Resolve-Path -Path $root
$root = $root.ProviderPath

$urlHttp = "http://localhost:$Port/$Page"
$fileUrl = ('file:///' + (Join-Path $root $Page)) -replace '\\','/'

function Find-Chrome {
  $candidates = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles(x86)\Google\Chrome\Application\chrome.exe",
    "$env:LocalAppData\Google\Chrome\Application\chrome.exe"
  )
  foreach($p in $candidates){ if(Test-Path $p){ return $p } }
  return $null
}

function Test-Url($u){
  try{ Invoke-WebRequest -Uri $u -UseBasicParsing -Method Head -TimeoutSec 3 > $null; return $true }catch{ return $false }
}

Write-Host "Opening site from root: $root"

$target = $null
if(Test-Url $urlHttp){
  Write-Host "Found HTTP server at $urlHttp"
  $target = $urlHttp
} else {
  # Try to start python http.server in a new PowerShell window
  $python = Get-Command python -ErrorAction SilentlyContinue
  if($python){
    Write-Host "Starting Python http.server on port $Port... (new window)"
    $cmd = "cd '" + ($root -replace "'","''") + "'; python -m http.server $Port"
    Start-Process -FilePath powershell -ArgumentList "-NoExit","-Command", $cmd -WindowStyle Normal
    Start-Sleep -Seconds 1
    $target = $urlHttp
  } else {
    Write-Host "Python not found. Will open the HTML file directly in your browser."
    $target = $fileUrl
  }
}

$chrome = Find-Chrome
if($chrome){
  Write-Host "Opening in Chrome: $target"
  Start-Process -FilePath $chrome -ArgumentList $target
} else {
  Write-Host "Opening in default browser: $target"
  Start-Process $target
}

Write-Host "Done. If you started a Python server, a new window will remain open to keep it running."
