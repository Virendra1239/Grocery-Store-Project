// products management using localStorage
function getProducts(){
    const raw = localStorage.getItem('products');
    return raw ? JSON.parse(raw) : [];
}
function saveProducts(arr){
    localStorage.setItem('products', JSON.stringify(arr));
}

function renderProducts(){
    const tbody = document.querySelector('#productsTable tbody');
    const products = getProducts();
    tbody.innerHTML = '';
    // render low-stock notifications
    try{
        const lowEl = document.getElementById('lowStockAlerts');
        if(lowEl){
            const threshold = 5; // low stock threshold
            const low = products.filter(p => (Number(p.stock) || 0) > 0 && (Number(p.stock) || 0) <= threshold);
            if(low.length > 0){
                lowEl.innerHTML = '<div style="padding:10px;border-radius:8px;background:#fff3cd;border:1px solid #ffeeba;color:#856404"><strong>Low stock:</strong> ' + low.map(p=> `${p.name} (${p.stock})`).join(' · ') + '</div>';
            } else {
                lowEl.innerHTML = '';
            }
        }
    }catch(e){ }
    products.forEach((p, idx) => {
        const tr = document.createElement('tr');
        const shortDesc = (p.description || '') ? (p.description.length > 80 ? (p.description.substr(0,77) + '...') : p.description) : '';
        const stockCount = Number(p.stock) || 0;
        tr.innerHTML = `
            <td>${idx+1}</td>
            <td><img class="product-img" src="${p.image || '../fruits.jpg'}" alt="${p.name}"/></td>
            <td>${p.name}</td>
            <td title="${(p.description||'').replace(/"/g,'&quot;')}">${shortDesc}</td>
            <td>${p.price}</td>
            <td>
                <input type="number" min="0" value="${stockCount}" data-stock-index="${idx}" style="width:80px" />
                ${stockCount <= 0 ? '<div style="margin-top:6px"><span class="badge bg-danger">Out of stock</span></div>' : ''}
            </td>
            <td>
                <button class="btn btn-sm btn-danger" data-action="delete" data-index="${idx}">Delete</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
    // update dashboard counts if present
    if(document.getElementById('totalProducts')){
        document.getElementById('totalProducts').textContent = products.length;
    }
}

document.addEventListener('DOMContentLoaded', function(){
    // protect page: require adminLoggedIn
    if(!sessionStorage.getItem('adminLoggedIn')){
        window.location.href = 'login.html';
        return;
    }

    renderProducts();

    // image URL preview and validation
    const pimageInput = document.getElementById('pimage');
    const previewImg = document.getElementById('pimagePreview');
    const pimgError = document.getElementById('pimgError');
    function validateImageUrl(url){
        // quick heuristic: allow relative paths or http(s) urls
        if(!url) return true;
        try{
            // if it's relative, new URL will throw in some browsers, so permit when it doesn't start with http
            if(url.startsWith('http://') || url.startsWith('https://')){
                new URL(url);
            }
            return true;
        } catch(e){
            return false;
        }
    }
    let previewLoader = null;
    pimageInput.addEventListener('input', function(){
        const url = this.value.trim();
        pimgError.style.display = 'none';
        if(!url){ previewImg.src = '../fruits.jpg'; return; }
        // try to load the image using a new Image object to detect errors
        if(previewLoader){ previewLoader.onload = previewLoader.onerror = null; }
        previewLoader = new Image();
        previewLoader.onload = function(){ previewImg.src = url; };
        previewLoader.onerror = function(){ pimgError.textContent = 'Cannot load image from this URL'; pimgError.style.display = 'block'; previewImg.src = '../fruits.jpg'; };
        previewLoader.src = url;
    });

    document.getElementById('addProductForm').addEventListener('submit', function(e){
        e.preventDefault();
    const name = document.getElementById('pname').value.trim();
    const price = parseFloat(document.getElementById('pprice').value) || 0;
    const image = document.getElementById('pimage').value.trim();
    const description = document.getElementById('pdesc') ? document.getElementById('pdesc').value.trim() : '';
    const stock = Math.max(0, parseInt(document.getElementById('pstock')?.value || '0', 10));
        // validate image URL format (basic)
        if(image && !validateImageUrl(image)){
            pimgError.textContent = 'Invalid image URL'; pimgError.style.display = 'block';
            return;
        }
    const products = getProducts();
    products.push({name, price, image, description, stock});
        saveProducts(products);
        renderProducts();
        this.reset();
        previewImg.src = '../fruits.jpg';
        alert('Product added');
    });

    document.querySelector('#productsTable').addEventListener('click', function(e){
        const btn = e.target.closest('button');
        if(!btn) return;
        const action = btn.getAttribute('data-action');
        const index = parseInt(btn.getAttribute('data-index'));
        if(action === 'delete'){
            if(confirm('Delete this product?')){
                const products = getProducts();
                products.splice(index,1);
                saveProducts(products);
                renderProducts();
            }
        }
    });

    // inline stock edits
    document.querySelector('#productsTable').addEventListener('change', function(e){
        const el = e.target;
        if(!el) return;
        const si = el.getAttribute('data-stock-index');
        if(si != null){
            const idx = Number(si);
            const val = Math.max(0, parseInt(el.value || '0', 10));
            const products = getProducts();
            if(products[idx]){
                products[idx].stock = val;
                saveProducts(products);
                renderProducts();
            }
        }
    });
});

// --- Gallery management: allow uploading images and storing them in localStorage.gallery ---
(function(){
    function getGallery(){ try{ return JSON.parse(localStorage.getItem('gallery')||'[]') }catch(e){ return []; } }
    function saveGallery(g){ localStorage.setItem('gallery', JSON.stringify(g)); }

    function renderGallery(){
        const container = document.getElementById('imageGallery');
        if(!container) return;
        const gallery = getGallery();
        container.innerHTML = '';
        if(gallery.length === 0){ container.innerHTML = '<div class="text-muted">No uploaded images yet</div>'; return }
        gallery.forEach((g, idx) => {
            const thumb = document.createElement('div');
            thumb.className = 'gallery-thumb';
            thumb.style.display = 'inline-block';
            thumb.style.margin = '6px';
            thumb.style.position = 'relative';
            thumb.innerHTML = `<img src="${g.data}" alt="${g.name||'img'}" style="width:84px;height:84px;object-fit:cover;border-radius:6px;border:1px solid #eee;cursor:pointer" data-idx="${idx}">` +
                `<button class="btn btn-sm btn-danger" data-action="del-gallery" data-idx="${idx}" style="position:absolute;top:-6px;right:-6px;border-radius:999px;padding:4px 6px">×</button>`;
            container.appendChild(thumb);
        });
    }

    // wire upload input
    document.addEventListener('DOMContentLoaded', ()=>{
        const up = document.getElementById('uploadImage');
        const pimageInput = document.getElementById('pimage');
        const previewImg = document.getElementById('pimagePreview');
        if(up){
            up.addEventListener('change', function(){
                const f = this.files && this.files[0];
                if(!f) return;
                const reader = new FileReader();
                reader.onload = function(ev){
                    const data = ev.target.result;
                    const gallery = getGallery();
                    const item = { id: Date.now(), name: f.name, data };
                    gallery.unshift(item); // newest first
                    saveGallery(gallery);
                    renderGallery();
                    // select uploaded image into product image input and preview
                    if(pimageInput){ pimageInput.value = data; }
                    if(previewImg){ previewImg.src = data; }
                    alert('Image uploaded to gallery and selected for product');
                };
                reader.readAsDataURL(f);
                // clear input so same file can be re-selected later
                this.value = '';
            });
        }

        // render gallery container if present
        renderGallery();

        // clicking gallery thumbnail selects image into pimage
        document.getElementById('imageGallery')?.addEventListener('click', function(e){
            const img = e.target.closest('img[data-idx]');
            if(img){
                const idx = Number(img.getAttribute('data-idx'));
                const gallery = getGallery();
                const item = gallery[idx];
                if(item){
                    if(pimageInput) pimageInput.value = item.data;
                    if(previewImg) previewImg.src = item.data;
                }
                return;
            }
            const del = e.target.closest('button[data-action="del-gallery"]');
            if(del){
                const idx = Number(del.getAttribute('data-idx'));
                if(!confirm('Delete this gallery image?')) return;
                const gallery = getGallery();
                gallery.splice(idx,1);
                saveGallery(gallery);
                renderGallery();
            }
        });

        // update gallery if changed in another tab
        window.addEventListener('storage', (ev)=>{ if(ev.key === 'gallery') renderGallery(); });
    });
})();
