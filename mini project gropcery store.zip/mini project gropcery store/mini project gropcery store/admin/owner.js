(function(){
  // Owner panel script: single owner account management and admin listing
  function sha256hex(str){ const enc = new TextEncoder().encode(str); return crypto.subtle.digest('SHA-256', enc).then(hash=> Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,'0')).join('')); }

  function getOwner(){ try{ return JSON.parse(localStorage.getItem('owner')||'null') }catch(e){ return null } }
  function saveOwner(o){ localStorage.setItem('owner', JSON.stringify(o)); }

  function getAdmins(){ try{ return JSON.parse(localStorage.getItem('admins')||localStorage.getItem('admins')||'[]') }catch(e){ return [] } }
  function saveAdmins(list){ localStorage.setItem('admins', JSON.stringify(list)); }

  function renderSetup(){
    const area = document.getElementById('ownerArea'); area.innerHTML = '';
    const note = document.createElement('div'); note.className='note'; note.textContent = 'No owner account found. Create the single owner account now. This account can manage admin accounts.';
    const form = document.createElement('div');
    form.innerHTML = `
      <div><input id="owner_name" placeholder="Full name"></div>
      <div><input id="owner_email" placeholder="Email"></div>
      <div class="row"><div class="col"><input id="owner_pass" type="password" placeholder="Password"></div><div class="col"><input id="owner_pass2" type="password" placeholder="Confirm password"></div></div>
      <div style="margin-top:8px"><button id="createOwnerBtn" class="btn">Create owner account</button></div>
    `;
    area.appendChild(note); area.appendChild(form);
    document.getElementById('createOwnerBtn').addEventListener('click', async ()=>{
      const name = document.getElementById('owner_name').value.trim(); const email = document.getElementById('owner_email').value.trim().toLowerCase();
      const pass = document.getElementById('owner_pass').value; const pass2 = document.getElementById('owner_pass2').value;
      if(!name||!email||!pass) return alert('Please fill all fields'); if(pass!==pass2) return alert('Passwords do not match');
      const hash = await sha256hex(pass);
      const owner = { id: Date.now(), name, email, passwordHash: hash };
      saveOwner(owner);
      alert('Owner account created. Please login.');
      renderLogin();
    });
  }

  function renderLogin(){
    const area = document.getElementById('ownerArea'); area.innerHTML = '';
    const form = document.createElement('div');
    form.innerHTML = `
      <div style="margin-bottom:8px"><input id="login_email" placeholder="Email"></div>
      <div style="margin-bottom:8px"><input id="login_pass" type="password" placeholder="Password"></div>
      <div style="display:flex;gap:8px"><button id="loginBtn" class="btn">Login</button><button id="gotoSetup" class="btn" style="background:#6b7280">Recreate owner</button></div>
    `;
    area.appendChild(form);
    document.getElementById('loginBtn').addEventListener('click', async ()=>{
      const email = document.getElementById('login_email').value.trim().toLowerCase(); const pass = document.getElementById('login_pass').value;
      if(!email||!pass) return alert('Enter email & password');
      const owner = getOwner(); if(!owner) return alert('No owner found');
      const hash = await sha256hex(pass);
      if(hash !== owner.passwordHash) return alert('Invalid credentials');
      sessionStorage.setItem('ownerLoggedIn','true'); sessionStorage.setItem('ownerId', String(owner.id));
      renderDashboard();
    });
    document.getElementById('gotoSetup').addEventListener('click', ()=>{ if(confirm('This will remove the existing owner and allow creating a new owner. Continue?')){ localStorage.removeItem('owner'); renderSetup(); } });
  }

  function renderDashboard(){
    const area = document.getElementById('ownerArea'); area.innerHTML = '';
    const hdr = document.createElement('div'); hdr.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center"><strong>Owner dashboard</strong><div><button id="ownerLogoutBtn" class="btn" style="background:#ef4444">Logout</button></div></div>`;
    area.appendChild(hdr);
    document.getElementById('ownerLogoutBtn').addEventListener('click', ()=>{ logout(); });

    // Admins list
    const admins = getAdmins() || [];
    const section = document.createElement('div');
    section.innerHTML = `<h3 style="margin-top:12px">Admin accounts</h3>`;
    const table = document.createElement('table'); const thead = document.createElement('thead'); thead.innerHTML = '<tr><th>Name</th><th>Email</th><th>Actions</th></tr>'; table.appendChild(thead);
    const tbody = document.createElement('tbody');
    admins.forEach((a, idx)=>{
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${a.name||'-'}</td><td>${a.email||'-'}</td><td><button data-idx="${idx}" class="btn danger small">Delete</button></td>`;
      tbody.appendChild(tr);
    });
    table.appendChild(tbody); section.appendChild(table);
    area.appendChild(section);

    // delete handler
    table.querySelectorAll('button[data-idx]').forEach(b=> b.addEventListener('click', (ev)=>{
      const idx = Number(b.getAttribute('data-idx'));
      if(!confirm('Delete this admin account?')) return;
      admins.splice(idx,1); saveAdmins(admins); renderDashboard();
    }));

    // Add admin form
    const addForm = document.createElement('div'); addForm.style.marginTop='12px';
    addForm.innerHTML = `
      <h3>Create admin account</h3>
      <div><input id="newAdminName" placeholder="Full name"></div>
      <div><input id="newAdminEmail" placeholder="Email"></div>
      <div class="row"><div class="col"><input id="newAdminPass" type="password" placeholder="Password"></div><div class="col"><input id="newAdminPass2" type="password" placeholder="Confirm password"></div></div>
      <div style="margin-top:8px"><button id="createAdminBtn" class="btn">Create Admin</button></div>
    `;
    area.appendChild(addForm);
    document.getElementById('createAdminBtn').addEventListener('click', async ()=>{
      const name = document.getElementById('newAdminName').value.trim(); const email = document.getElementById('newAdminEmail').value.trim().toLowerCase();
      const pass = document.getElementById('newAdminPass').value; const pass2 = document.getElementById('newAdminPass2').value;
      if(!name||!email||!pass) return alert('Please fill all fields'); if(pass!==pass2) return alert('Passwords do not match');
      const adminsList = getAdmins() || [];
      if(adminsList.find(a=>a.email===email)) return alert('Admin with this email already exists');
      const hash = await sha256hex(pass);
      const admin = { id: Date.now(), name, email, passwordHash: hash };
      adminsList.push(admin); saveAdmins(adminsList);
      alert('Admin created'); renderDashboard();
    });

    // quick links
    const links = document.createElement('div'); links.style.marginTop='12px'; links.innerHTML = '<h3 class="small">Quick links</h3><div class="small"><a href="../admin/orders.html">View orders</a> · <a href="../admin/products.html">Manage products</a> · <a href="../grocerystorepaymentgateway.html">Payment page</a></div>';
    area.appendChild(links);
    // Commission settings (owner can set a global commission percentage applied to product prices)
    const settings = getOwnerSettings();
    const comWrap = document.createElement('div'); comWrap.style.marginTop = '16px';
    comWrap.innerHTML = `
      <h3 style="margin-top:12px">Commission settings</h3>
      <div class="small muted">Set a global commission percentage applied to product prices on the storefront. Example: 10 means +10% on price.</div>
      <div style="margin-top:8px;display:flex;gap:8px;align-items:center">
        <input id="commissionPercent" placeholder="Commission %" style="width:120px;padding:8px;border:1px solid #ddd;border-radius:6px" value="${settings && settings.commissionPercent ? settings.commissionPercent : ''}">
        <button id="saveCommission" class="btn">Save</button>
        <button id="clearCommission" class="btn" style="background:#6b7280">Clear</button>
      </div>
      <div id="commissionPreview" style="margin-top:12px" class="small"></div>
    `;
    area.appendChild(comWrap);

    document.getElementById('saveCommission').addEventListener('click', ()=>{
      const v = Number(document.getElementById('commissionPercent').value || 0);
      if(isNaN(v) || v < 0) return alert('Enter a valid commission percent');
      saveOwnerSettings({ commissionPercent: v });
      alert('Commission saved');
      renderDashboard();
    });
    document.getElementById('clearCommission').addEventListener('click', ()=>{
      if(!confirm('Clear commission setting?')) return;
      saveOwnerSettings({});
      renderDashboard();
    });

    // Preview sample using products (if available)
    const previewEl = document.getElementById('commissionPreview');
    try{
      const proRaw = localStorage.getItem('products');
      const products = proRaw ? JSON.parse(proRaw) : [];
      if(products && products.length){
        const pct = Number((getOwnerSettings()||{}).commissionPercent) || 0;
        const rows = products.slice(0,5).map(p=>{
          const base = Number(p.price) || 0; const final = (base + (base * pct / 100)).toFixed(2);
          return `<div>${p.name} — base: Rs ${base} → final: Rs ${final} (${pct}% commission)</div>`;
        }).join('');
        previewEl.innerHTML = rows;
      } else { previewEl.innerHTML = '<div class="muted">No products available to preview.</div>'; }
    }catch(e){ previewEl.innerHTML = '<div class="muted">Unable to render preview.</div>'; }
  }

  function logout(){ sessionStorage.removeItem('ownerLoggedIn'); sessionStorage.removeItem('ownerId'); renderInitial(); }

  function renderInitial(){
    const owner = getOwner();
    if(!owner) renderSetup(); else if(sessionStorage.getItem('ownerLoggedIn')==='true') renderDashboard(); else renderLogin();
    // show/hide header logout link
    const hl = document.getElementById('owner-logout'); if(hl){ hl.style.display = sessionStorage.getItem('ownerLoggedIn')==='true' ? 'inline' : 'none'; hl.onclick = logout; }
  }

  // Owner settings helpers
  function getOwnerSettings(){ try{ return JSON.parse(localStorage.getItem('ownerSettings')||'{}') }catch(e){ return {} } }
  function saveOwnerSettings(s){ localStorage.setItem('ownerSettings', JSON.stringify(s||{})); }

  // expose helper to check owner auth from other pages
  window.isOwnerLoggedIn = function(){ return sessionStorage.getItem('ownerLoggedIn')==='true'; }

  // Initialize
  document.addEventListener('DOMContentLoaded', renderInitial);
})();
