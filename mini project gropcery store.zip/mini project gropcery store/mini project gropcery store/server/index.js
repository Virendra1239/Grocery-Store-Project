const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// In-memory stores for demo. Replace with DB for production.
let deliveries = [];
let drivers = []; // { id, name, phone, vehicle, license, passwordHash }
const driverTokens = {}; // token -> driverId
const adminTokens = new Set();

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123'; // change in production

function generateToken(){ return crypto.randomBytes(24).toString('hex'); }

function sanitizeDriver(d){ const { passwordHash, ...rest } = d; return rest; }

app.get('/health', (req, res) => res.json({ ok: true }));

app.get('/deliveries/:id', (req, res) => {
  const d = deliveries.find(x => x.id === req.params.id);
  if (!d) return res.status(404).json({ error: 'not found' });
  res.json(d);
});

// Driver registration (server-side auth)
app.post('/drivers/register', async (req, res) => {
  try{
    const { name, phone, vehicle, license, password } = req.body || {};
    if(!name || !phone || !password) return res.status(400).json({ error: 'name, phone and password required' });
    if(drivers.find(x=> x.phone === phone)) return res.status(409).json({ error: 'driver exists' });
    const passwordHash = await bcrypt.hash(password, 10);
    const id = 'DRV' + Date.now();
    const drv = { id, name, phone, vehicle, license, passwordHash };
    drivers.push(drv);
    return res.json({ ok: true, driver: sanitizeDriver(drv) });
  }catch(e){ console.error(e); return res.status(500).json({ error: 'server error' }); }
});

// Driver login
app.post('/drivers/login', async (req, res) => {
  try{
    const { phone, password } = req.body || {};
    if(!phone || !password) return res.status(400).json({ error: 'phone and password required' });
    const drv = drivers.find(x=> x.phone === phone);
    if(!drv) return res.status(401).json({ error: 'invalid credentials' });
    const ok = await bcrypt.compare(password, drv.passwordHash || '');
    if(!ok) return res.status(401).json({ error: 'invalid credentials' });
    const token = generateToken(); driverTokens[token] = drv.id;
    return res.json({ ok: true, token, driver: sanitizeDriver(drv) });
  }catch(e){ console.error(e); return res.status(500).json({ error: 'server error' }); }
});

// Admin login -> returns token
app.post('/admin/login', (req, res) => {
  const { password } = req.body || {};
  if(!password) return res.status(400).json({ error: 'password required' });
  if(password !== ADMIN_PASSWORD) return res.status(401).json({ error: 'invalid password' });
  const token = generateToken(); adminTokens.add(token); return res.json({ ok: true, token });
});

// middleware to check admin token
function requireAdmin(req, res, next){
  const auth = (req.headers.authorization || '').replace(/^Bearer\s*/i, '');
  if(!auth || !adminTokens.has(auth)) return res.status(401).json({ error: 'unauthorized' });
  next();
}

// protected drivers list for admin
app.get('/drivers', requireAdmin, (req, res) => {
  res.json(drivers.map(sanitizeDriver));
});

// update driver profile (admin)
app.put('/drivers/:id', requireAdmin, (req, res) => {
  const id = req.params.id; const idx = drivers.findIndex(d=> d.id === id);
  if(idx === -1) return res.status(404).json({ error: 'not found' });
  const update = req.body || {};
  // only allow some fields
  ['name','phone','vehicle','license'].forEach(k=>{ if(update[k] !== undefined) drivers[idx][k] = update[k]; });
  return res.json({ ok: true, driver: sanitizeDriver(drivers[idx]) });
});

// Accept updates from admin (or clients) and broadcast to subscribers
app.post('/deliveries/update', (req, res) => {
  const d = req.body;
  if (!d || !d.id) return res.status(400).json({ error: 'missing id' });
  const idx = deliveries.findIndex(x => x.id === d.id);
  if (idx === -1) deliveries.push(d); else deliveries[idx] = d;
  // broadcast to room
  try { io.to('delivery:' + d.id).emit('delivery:update', d); } catch (e) { console.warn('emit failed', e); }
  return res.json({ ok: true });
});

io.on('connection', socket => {
  console.log('socket connected', socket.id);
  socket.on('subscribe', data => {
    if (data && data.deliveryId) {
      const room = 'delivery:' + data.deliveryId;
      socket.join(room);
      console.log('socket', socket.id, 'joined', room);
    }
  });

  socket.on('delivery:update', (d) => {
    if (!d || !d.id) return;
    const idx = deliveries.findIndex(x => x.id === d.id);
    if (idx === -1) deliveries.push(d); else deliveries[idx] = d;
    io.to('delivery:' + d.id).emit('delivery:update', d);
  });

  socket.on('disconnect', () => { console.log('socket disconnected', socket.id); });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('Realtime server listening on port', PORT));
