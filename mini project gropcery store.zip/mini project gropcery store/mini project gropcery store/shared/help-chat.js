// Simple client-side help chatbot with canned responses.
(function(){
  const widgetId = 'helpChatWidget';
  const toggleId = 'chatToggle';
  const panelId = 'chatPanel';
  const closeId = 'chatClose';
  const formId = 'chatForm';
  const inputId = 'chatInput';
  const messagesId = 'chatMessages';

  // Simple FAQ patterns -> responses
  const RESPONSES = [
    {q:/order|place an order/i, a:"To place an order, add items to your cart and proceed to checkout. You can edit quantities in the cart before payment."},
    {q:/payment|pay|card/i, a:"We accept card payments. Follow the checkout flow to enter your card details."},
    {q:/delivery|track|tracking/i, a:"After your order is confirmed you'll receive an estimated delivery time. Contact support if you need updates."},
    {q:/return|returns|refund/i, a:"If an item arrives damaged or incorrect, email us within 48 hours at chaurasiyavirendra9118@gmail.com and we'll help with a return or refund."},
    {q:/job|career|work/i, a:"Visit our Careers page for open positions: careers.html"},
    {q:/help|support/i, a:"You can browse the Help Center FAQs or provide your question here and we'll try to help."}
  ];

  function $(id){ return document.getElementById(id); }

  function appendMsg(text, cls){
    const container = $(messagesId);
    if(!container) return;
    const div = document.createElement('div');
    div.className = 'msg ' + cls;
    div.textContent = text;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
  }

  function findResponse(text){
    for(const r of RESPONSES){ if(r.q.test(text)) return r.a; }
    return null;
  }

  function onSend(raw){
    const text = (raw||'').trim();
    if(!text) return;
    appendMsg(text, 'user');
    // simulated thinking
    setTimeout(()=>{
      const res = findResponse(text);
      if(res){ appendMsg(res, 'bot'); }
      else { appendMsg("Sorry, I don't have an answer for that yet. Try the Help Center or email support at chaurasiyavirendra9118@gmail.com", 'bot'); }
    }, 550);
  }

  // init when DOM has footer injected
  function init(){
    const widget = $(widgetId);
    if(!widget) return;
    const toggle = $(toggleId);
    const panel = $(panelId);
    const closeBtn = $(closeId);
    const form = $(formId);
    const input = $(inputId);

    // Only show on help page by default (optional): detect pathname
    try{
      const path = location.pathname || location.href;
      if(!/help\.html$/i.test(path) && !/help/i.test(path)){
        // keep collapsed but available — don't auto-open
      }
    }catch(e){}

    if(toggle){ toggle.addEventListener('click', ()=>{
      if(panel.style.display === 'flex'){
        panel.style.display = 'none';
        widget.setAttribute('aria-hidden','true');
      } else {
        panel.style.display = 'flex';
        widget.setAttribute('aria-hidden','false');
        // greet
        const msgs = $(messagesId);
        if(msgs && msgs.children.length === 0) appendMsg('Hi — I can help with orders, payments, delivery and returns. Ask me a question or type "help" to see options.', 'bot');
      }
    }); }

    if(closeBtn){ closeBtn.addEventListener('click', ()=>{ panel.style.display='none'; widget.setAttribute('aria-hidden','true'); }); }

    if(form){ form.addEventListener('submit',(ev)=>{ ev.preventDefault(); onSend(input.value); input.value=''; input.focus(); }); }

    // quick keyboard: focus
    document.addEventListener('keydown',(e)=>{ if(e.key === 'k' && (e.ctrlKey || e.metaKey)){ const i=$(inputId); if(i){ i.focus(); } } });
  }

  // wait for injection (footer.js appends script after injection so DOM should be ready). Use small delay guard.
  setTimeout(init, 150);

})();
