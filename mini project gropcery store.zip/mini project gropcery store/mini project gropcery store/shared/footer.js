// Inject shared footer fragment into pages with <footer id="site-footer"></footer>
(function(){
  function insertFooter(){
    const el = document.getElementById('site-footer');
    if(!el) return;
    fetch('shared/footer.html').then(r=> r.text()).then(html=>{
      el.className = 'site-footer';
      el.innerHTML = html;
      const y = document.getElementById('footerYear'); if(y) y.textContent = new Date().getFullYear();
      // load chat script (if present) after footer injection so it can bind to injected markup
      try{
        // avoid loading multiple times
        if(!document.getElementById('shared-help-chat-script')){
          const s = document.createElement('script');
          s.id = 'shared-help-chat-script';
          s.src = 'shared/help-chat.js';
          s.async = true;
          s.onload = function(){ /* loaded */ };
          s.onerror = function(){ console.warn('help-chat script failed to load'); };
          document.body.appendChild(s);
        }
      }catch(e){ console.warn('chat attach failed', e); }
    }).catch(err=>{
      console.warn('Footer load failed', err);
      // fallback: minimal footer
      el.className = 'site-footer';
      el.innerHTML = '<div style="padding:20px;color:#fff;background:#111">© '+new Date().getFullYear()+' Grocery Store</div>';
    });
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', insertFooter);
  else insertFooter();
})();
