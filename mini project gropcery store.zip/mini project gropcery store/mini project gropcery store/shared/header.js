// Shared header script: updates cart count and binds search/admin/cart links
(() => {
    function getCartCount(){
        try{
            const c = JSON.parse(localStorage.getItem('cart')||'[]');
            return Array.isArray(c) ? c.reduce((s,i)=> s + ((Number(i.quantity) || Number(i.qty) || 1)), 0) : 0;
        }catch(e){ return 0 }
    }

    function updateCartCounts(){
        document.querySelectorAll('.cart-count').forEach(el=> el.textContent = getCartCount());
    }

    // on load
    document.addEventListener('DOMContentLoaded', ()=>{
        updateCartCounts();

        // bind search if present
        const searchInput = document.querySelector('.site-header input[data-search]');
        const searchBtn = document.querySelector('.site-header [data-search-btn]');
        if(searchBtn && searchInput){
            searchBtn.addEventListener('click', ()=>{
                const q = searchInput.value.trim();
                // collect optional filter fields (category, max price, sort)
                const catEl = document.querySelector('.site-header select[data-filter-cat]');
                const maxEl = document.querySelector('.site-header input[data-filter-max]');
                const sortEl = document.querySelector('.site-header select[data-filter-sort]');
                const cat = catEl ? catEl.value.trim() : '';
                const max = maxEl ? (maxEl.value ? String(maxEl.value).trim() : '') : '';
                const sort = sortEl ? sortEl.value.trim() : '';
                // navigate to groceryStore.html with query params (pages can read ?q, ?category, ?max, ?sort)
                let target = 'groceryStore.html';
                const parts = [];
                if(q) parts.push('q=' + encodeURIComponent(q));
                if(cat) parts.push('category=' + encodeURIComponent(cat));
                if(max) parts.push('max=' + encodeURIComponent(max));
                if(sort) parts.push('sort=' + encodeURIComponent(sort));
                if(parts.length) target += '?' + parts.join('&');
                window.location.href = target;
            });
            searchInput.addEventListener('keydown', (e)=>{ if(e.key === 'Enter') searchBtn.click(); });
        }

        // update when storage changes in other tabs
        window.addEventListener('storage', (e)=>{ if(e.key === 'cart') updateCartCounts(); });

        // admin link: if logged in, go to admin index else to admin login
        document.querySelectorAll('.admin-link').forEach(el=>{
            el.addEventListener('click', (ev)=>{
                ev.preventDefault();
                const logged = sessionStorage.getItem('adminLoggedIn');
                if(logged === 'true') window.location.href = 'admin/index.html';
                else window.location.href = 'admin/login.html';
            });
        });

        // user login link: update display if user is logged in and provide logout
        const userLinks = document.querySelectorAll('.user-link');
        function updateUserLinks(){
            const raw = sessionStorage.getItem('user');
            const user = raw ? JSON.parse(raw) : null;
            userLinks.forEach(el=>{
                if(user){
                    const name = user.name || (user.email ? user.email.split('@')[0] : 'User');
                    el.textContent = 'Hi, ' + name;
                    // if this element is intended to open an in-page modal, don't override href
                    if(!el.dataset.openModal) el.href = '#';
                    el.classList.add('logged-in');
                } else {
                    el.textContent = 'Login';
                    // respect data-open-modal attribute: if present, leave href and attach click handler
                    if(!el.dataset.openModal) el.href = 'login.html';
                    el.classList.remove('logged-in');
                }
                // attach click handler to open modal if requested
                if(el.dataset.openModal === 'true'){
                    el.addEventListener('click', (ev)=>{ ev.preventDefault(); if(typeof window.showLoginModal === 'function') window.showLoginModal(); else window.location.href = el.href; });
                }
            });
            // show logout button next to first user-link when logged in
            const actions = document.querySelector('.site-header .actions');
            if(!actions) return;
            let logoutBtn = document.querySelector('.user-logout-btn');
            if(user && !logoutBtn){
                logoutBtn = document.createElement('button');
                logoutBtn.className = 'user-logout-btn';
                logoutBtn.textContent = 'Logout';
                logoutBtn.style.marginLeft = '8px';
                logoutBtn.style.padding = '6px 10px';
                logoutBtn.style.borderRadius = '8px';
                logoutBtn.style.border = 'none';
                logoutBtn.style.cursor = 'pointer';
                logoutBtn.addEventListener('click', ()=>{ sessionStorage.removeItem('user'); updateUserLinks(); window.location.href = 'groceryStore.html'; });
                actions.appendChild(logoutBtn);
            }
            if(!user && logoutBtn) logoutBtn.remove();
        }
        updateUserLinks();
        window.addEventListener('storage', (e)=>{ if(e.key === 'user' || e.key === 'adminLoggedIn') updateUserLinks(); });
    });

    // expose for debugging
    window.__sharedHeader = { updateCartCounts };

})();
