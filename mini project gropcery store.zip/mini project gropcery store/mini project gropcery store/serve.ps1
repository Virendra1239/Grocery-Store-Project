# Simple static file server for Windows PowerShell (uses HttpListener)
# Usage: open PowerShell in this folder and run: .\serve.ps1
# If execution policy blocks, run: powershell -ExecutionPolicy Bypass -File .\serve.ps1

$prefix = "http://localhost:8000/"
$root = Split-Path -Parent $MyInvocation.MyCommand.Definition

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)

try {
    $listener.Start()
    Write-Host "Serving files from: $root"
    Write-Host "Open http://localhost:8000/groceryStore.html in your browser"

    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $urlPath = [System.Uri]::UnescapeDataString($request.Url.AbsolutePath.TrimStart('/'))
        if ([string]::IsNullOrEmpty($urlPath)) { $urlPath = 'groceryStore.html' }

        $filePath = Join-Path $root $urlPath

        if (-not (Test-Path $filePath)) {
            $response.StatusCode = 404
            $response.ContentType = 'text/plain; charset=utf-8'
            $bytes = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found: $urlPath")
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.OutputStream.Close()
            continue
        }

        try {
            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            switch ($ext) {
                '.html' { $ctype = 'text/html; charset=utf-8' }
                '.htm' { $ctype = 'text/html; charset=utf-8' }
                '.css' { $ctype = 'text/css' }
                '.js' { $ctype = 'application/javascript' }
                '.json' { $ctype = 'application/json' }
                '.png' { $ctype = 'image/png' }
                '.jpg' { $ctype = 'image/jpeg' }
                '.jpeg' { $ctype = 'image/jpeg' }
                '.webp' { $ctype = 'image/webp' }
                '.gif' { $ctype = 'image/gif' }
                '.svg' { $ctype = 'image/svg+xml' }
                default { $ctype = 'application/octet-stream' }
            }
            $response.ContentType = $ctype
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
            $response.OutputStream.Close()
        }
        catch {
            $response.StatusCode = 500
            $msg = "500 Internal Server Error`n$($_.Exception.Message)"
            $buffer = [System.Text.Encoding]::UTF8.GetBytes($msg)
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
            $response.OutputStream.Close()
        }
    }
}
catch {
    Write-Error "Failed to start server: $($_.Exception.Message)"
}
finally {
    if ($listener -and $listener.IsListening) {
        $listener.Stop()
        $listener.Close()
    }
}
